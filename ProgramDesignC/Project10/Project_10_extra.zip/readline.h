/*
Header file for readline.c file, contain the prototype of the function read_line.
*/
#ifndef READLINE_H
int read_line(char str[], int n);
#endif // READLINE_H
